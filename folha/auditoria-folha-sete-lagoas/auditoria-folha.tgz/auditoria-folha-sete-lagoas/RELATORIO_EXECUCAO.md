# Relatório de Execução — Auditoria Folha Saúde / Sete Lagoas

**Status:** SUCESSO  
**Motivo de encerramento:** claude_indisponivel_durante_loop  
**Gerado em:** 2026-06-16T10:05:14+00:00  

## Resultado
- Servidores ativos: 3215
- Custo bruto: R$ 20,419,944.15
- Gini: 0.3966
- Elite > R$20k: 146
- Cobertura legal (por valor): 87.43% (llm_barato)
- Dashboard: relatorio_custos_folha_saude_setelagoas.html (39 KB)

## Custo de API
```json
{
  "usd_ceiling": 3.0,
  "usd_spent": 0.0,
  "tokens_in": 0,
  "tokens_out": 0,
  "calls": 0,
  "by_model": {}
}
```

## Lacunas (self_check)
- nenhuma

## Rede de segurança determinística
```json
{"steps_deterministicos": ["compute_tables", "sapl_enrich", "classify_rubricas", "synthesize", "build_dashboard"]}
```